I'm currently working on this method
