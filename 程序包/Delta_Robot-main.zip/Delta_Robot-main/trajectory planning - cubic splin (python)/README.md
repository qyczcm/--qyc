The main file here is "trajectory_planning_cubic_spline.py". The other two are variations of the main file

THe main file works as it should. The problem is that the starting and finishing points in the EE path have unbounded jerk. 

I'm working on a solution for this problem by using the jacobian method.
