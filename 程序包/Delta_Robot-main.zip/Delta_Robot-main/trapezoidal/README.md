There are two files here and both work alright. 

point-to-point trapezoidal method: This file is suitable for trajectory planning between start and finishing points. 
The method applications is similar to 3-4-5 and 4-5-6-7 polynomial interpolation.

Multi-point trapezoidal method: This file is suitable for a path with few via-points. 
If the number of via-pionts is more than a certain number, then the error would become noticable. 
