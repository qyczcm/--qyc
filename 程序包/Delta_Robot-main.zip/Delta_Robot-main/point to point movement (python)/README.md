These two codes work without much problem. As it mentions in the names, the trajectory planning is done for two points A and B, which are the start and finish points of the EE path
