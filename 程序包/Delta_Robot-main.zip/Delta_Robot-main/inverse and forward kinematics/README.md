# INVERSE KINEMATICS METHOD 1
![IK](https://i.ibb.co/rGhpdxH/Cam-Scanner-08-18-2022-20-51.jpg)
in the [python code](https://github.com/ArthasMenethil-A/Delta_Robot/blob/main/inverse%20and%20forward%20kinematics/IK_method_1.py) i've written ```base_radius``` and ```EE_radius``` as the variables but they are not really the radius, they are the triangle sides (shown in the figure above) the method 2 also have this problem

# INVERSE KINEMATICS METHOD 2
in [this file](https://github.com/ArthasMenethil-A/Delta_Robot/blob/main/inverse%20and%20forward%20kinematics/IK_method_2.py) ```get_theta_ij()``` method, returns the IK answer which is angle $\theta$ of the actuator joints

# FORWARD KINEMATICS

