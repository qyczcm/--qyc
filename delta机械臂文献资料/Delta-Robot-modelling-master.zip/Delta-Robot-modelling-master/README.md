# Delta-Robot-modelling
Simulation of a parallel manipulator- delta robot
This project involves the simulation of Delta Robot which could be used to sort the packages and facilitate a high precision and fast performance application in the industrial space.
The simulation is done on MATLAB.
The MAIN file must be run as a Live Script, and contains the simulation.
